package com.example.boilermakex

import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class Choose_Login_And_Reg:AppCompatActivity {

    private val mLogin: Button? = null
    private val mRegister: Button? = null

    protected fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_choose__login__and__reg)
        mLogin = findViewById(R.id.login) as Button
        mRegister = findViewById(R.id.register) as Button
        mLogin.setOnClickListener(object : OnClickListener() {
            fun onClick(v: View?) {
                val i = Intent(this@Choose_Login_And_Reg, LoginActivity::class.java)
                startActivity(i)
            }
        })
        mRegister.setOnClickListener(object : OnClickListener() {
            fun onClick(v: View?) {
                val i = Intent(this@Choose_Login_And_Reg, RegisterActivity::class.java)
                startActivity(i)
            }
        })
    }


}